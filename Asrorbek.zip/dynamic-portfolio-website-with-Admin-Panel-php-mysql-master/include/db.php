<?php
$db=mysqli_connect("localhost","root","","iportfolio");
//if($db){
//    echo "databse is connected !";
//}else{
//    echo "something is wrong with database !";
//}